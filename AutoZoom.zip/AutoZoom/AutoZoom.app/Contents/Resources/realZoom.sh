#!/bin/bash

caffeinate -is ./zoom.sh $1 $2 >> ./std.txt 2>&1
