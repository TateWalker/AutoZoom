class FbsError(Exception):
    pass