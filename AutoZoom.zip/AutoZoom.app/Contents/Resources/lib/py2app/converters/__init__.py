"""
Resource data converters
"""
